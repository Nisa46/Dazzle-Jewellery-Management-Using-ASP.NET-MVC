﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EcommerceProject.Startup))]
namespace EcommerceProject
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
